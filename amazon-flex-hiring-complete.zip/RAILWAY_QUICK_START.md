# Railway Deployment - Quick Start

## TL;DR - 5 Minute Setup

### 1. Push to GitHub (Already Done ✓)
Your code is already in GitHub via Manus export.

### 2. Create Railway Project
```
1. Go to railway.app
2. Click "New Project" → "Deploy from GitHub"
3. Select your "amazon-flex-hiring" repository
4. Click "Deploy"
```

### 3. Add MySQL Database
```
1. In Railway dashboard, click "+ New"
2. Select "Database" → "MySQL"
3. Wait for provisioning (2-3 minutes)
```

### 4. Set Environment Variables
Go to **Variables** tab and add:

```
DATABASE_URL=mysql://[user]:[password]@[host]:3306/[database]
JWT_SECRET=generate-a-random-string-here
NODE_ENV=production
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://app.manus.im
OWNER_OPEN_ID=your-owner-id
OWNER_NAME=Your Name
BUILT_IN_FORGE_API_URL=https://api.manus.im/forge
BUILT_IN_FORGE_API_KEY=your-api-key
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im/forge
VITE_APP_TITLE=Amazon Flex Hiring
```

**Get these values from your Manus project Settings → Secrets**

### 5. Deploy
Railway will automatically build and deploy once variables are set.

### 6. Run Database Migrations
After deployment succeeds:
- Connect to the MySQL database via Railway
- Run SQL from `drizzle/migrations/` folder
- Or SSH into Railway and run: `pnpm drizzle-kit migrate`

### 7. Test
- Visit your Railway URL
- Test the form submission
- Check owner notifications

---

## Useful Railway Commands

### View Logs
```
railway logs
```

### Connect to Database
```
railway connect mysql
```

### Redeploy
```
railway up
```

---

## Common Issues

| Issue | Solution |
|-------|----------|
| Build fails | Check `Dockerfile` exists, run `pnpm install` locally first |
| Database connection error | Verify `DATABASE_URL` format and MySQL service is running |
| App crashes | Check logs: Railway Dashboard → Deployments → View Logs |
| Port issues | Don't hardcode port; use `process.env.PORT` |

---

## Get Help

- Full guide: See `RAILWAY_DEPLOYMENT.md`
- Railway docs: https://docs.railway.app
- Manus support: https://help.manus.im

---

**You're ready to deploy! 🚀**
