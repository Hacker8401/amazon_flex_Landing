# Railway Deployment Guide - Amazon Flex Landing Page

This guide walks you through deploying the Amazon Flex landing page to Railway.

## Prerequisites

- Railway account (sign up at [railway.app](https://railway.app))
- GitHub repository with the code (already connected via Manus)
- MySQL/TiDB database (Railway will help you set this up)

## Step-by-Step Deployment

### Step 1: Create a Railway Project

1. Go to [railway.app](https://railway.app) and log in
2. Click **"New Project"**
3. Select **"Deploy from GitHub"**
4. Authorize Railway to access your GitHub account
5. Select the repository: `amazon-flex-hiring` (or whatever you named it)
6. Select the main branch
7. Click **"Deploy"**

Railway will start building your application automatically.

---

### Step 2: Set Up MySQL Database

1. In your Railway project dashboard, click **"+ New"**
2. Select **"Database"** → **"MySQL"**
3. Railway will provision a MySQL database automatically
4. Copy the connection details (you'll need them for environment variables)

---

### Step 3: Configure Environment Variables

Railway will automatically detect some variables, but you need to add the critical ones:

1. In your Railway project, go to **Variables** tab
2. Add the following environment variables:

```
DATABASE_URL=mysql://[user]:[password]@[host]:[port]/[database]
JWT_SECRET=your-secret-key-here-generate-a-random-string
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://app.manus.im
OWNER_OPEN_ID=your-owner-open-id
OWNER_NAME=Your Name
BUILT_IN_FORGE_API_URL=https://api.manus.im/forge
BUILT_IN_FORGE_API_KEY=your-forge-api-key
VITE_FRONTEND_FORGE_API_KEY=your-frontend-forge-api-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im/forge
VITE_ANALYTICS_ENDPOINT=your-analytics-endpoint
VITE_ANALYTICS_WEBSITE_ID=your-analytics-id
VITE_APP_TITLE=Amazon Flex Hiring
VITE_APP_LOGO=your-logo-url
NODE_ENV=production
```

**Important:** Replace the placeholder values with your actual credentials from Manus.

---

### Step 4: Configure Port

1. In the **Variables** tab, make sure `PORT` is set to `3000` (or Railway's default)
2. The application will automatically use the PORT environment variable

---

### Step 5: Deploy

1. Once all environment variables are set, click **"Deploy"**
2. Railway will build your Docker image and deploy the application
3. You can monitor the build progress in the **Deployments** tab
4. Once deployment is complete, you'll get a public URL

---

### Step 6: Run Database Migrations

After deployment, you need to set up your database schema:

1. In Railway, go to the **MySQL** service
2. Click **"Connect"** and use a MySQL client to connect
3. Run the migration SQL from `drizzle/migrations/` directory
4. Or, you can SSH into your Railway deployment and run:
   ```bash
   pnpm drizzle-kit migrate
   ```

---

## Environment Variables Explained

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | MySQL connection string from Railway MySQL service |
| `JWT_SECRET` | Secret key for session cookies (generate a random string) |
| `VITE_APP_ID` | Manus OAuth application ID |
| `OAUTH_SERVER_URL` | Manus OAuth server URL |
| `OWNER_OPEN_ID` | Your Manus user ID (for owner notifications) |
| `BUILT_IN_FORGE_API_KEY` | API key for Manus services (server-side) |
| `VITE_FRONTEND_FORGE_API_KEY` | API key for frontend access to Manus services |
| `NODE_ENV` | Set to `production` for Railway |

---

## Getting Manus Credentials

To get your Manus credentials:

1. Go to your Manus project settings
2. In **Secrets** tab, you'll find all the pre-configured values
3. Copy them and paste into Railway environment variables

---

## Troubleshooting

### Build Fails
- Check that `Dockerfile` exists in the root directory
- Ensure `pnpm-lock.yaml` is committed to GitHub
- Check Railway logs for specific error messages

### Database Connection Error
- Verify `DATABASE_URL` is correct
- Ensure MySQL service is running in Railway
- Check that the database name exists

### Application Crashes After Deploy
- Check Railway logs: **Deployments** → **View Logs**
- Verify all required environment variables are set
- Ensure database migrations have been run

### Port Issues
- Railway automatically assigns a port; don't hardcode port 3000 in production
- The application reads from `process.env.PORT`

---

## Custom Domain (Optional)

To add a custom domain:

1. In Railway project, go to **Settings**
2. Under **Domains**, click **"+ Add Domain"**
3. Enter your domain name
4. Follow Railway's DNS configuration instructions
5. Wait for DNS to propagate (usually 24 hours)

---

## Monitoring & Logs

- **Logs**: Go to **Deployments** → **View Logs** to see real-time application logs
- **Metrics**: Check CPU, memory, and network usage in the **Metrics** tab
- **Health**: Railway automatically monitors your application health

---

## Redeploying

To redeploy after making changes:

1. Push changes to GitHub
2. Railway automatically detects changes and redeploys
3. Or manually trigger: **Deployments** → **Redeploy**

---

## Support

- Railway Docs: https://docs.railway.app
- Manus Support: https://help.manus.im
- GitHub Issues: Create an issue in your repository

---

## Next Steps

After successful deployment:

1. ✅ Test the landing page at your Railway URL
2. ✅ Test the lead form submission
3. ✅ Verify owner notifications are being sent
4. ✅ Set up custom domain (optional)
5. ✅ Monitor logs and metrics regularly
6. ✅ Set up automated backups for your database

---

**Happy deploying! 🚀**
