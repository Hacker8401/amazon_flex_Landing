import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("leads.submit", () => {
  it("should validate required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Test missing name
    await expect(
      caller.leads.submit({
        name: "",
        phone: "9876543210",
        city: "Bengaluru",
        vehicleType: "Bike",
      })
    ).rejects.toThrow();

    // Test invalid phone
    await expect(
      caller.leads.submit({
        name: "John Doe",
        phone: "123",
        city: "Bengaluru",
        vehicleType: "Bike",
      })
    ).rejects.toThrow();

    // Test missing city
    await expect(
      caller.leads.submit({
        name: "John Doe",
        phone: "9876543210",
        city: "",
        vehicleType: "Bike",
      })
    ).rejects.toThrow();

    // Test missing vehicle type
    await expect(
      caller.leads.submit({
        name: "John Doe",
        phone: "9876543210",
        city: "Bengaluru",
        vehicleType: "",
      })
    ).rejects.toThrow();
  });

  it("should accept valid lead submission", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.leads.submit({
      name: "John Doe",
      phone: "9876543210",
      city: "Bengaluru",
      vehicleType: "Bike",
    });

    expect(result.success).toBe(true);
    expect(result.lead).toBeDefined();
    expect(result.lead?.name).toBe("John Doe");
    expect(result.lead?.phone).toBe("9876543210");
    expect(result.lead?.city).toBe("Bengaluru");
    expect(result.lead?.vehicleType).toBe("Bike");
  });
});
