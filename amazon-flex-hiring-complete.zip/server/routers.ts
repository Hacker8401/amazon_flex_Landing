import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createLead } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  leads: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Name is required"),
          phone: z.string().min(10, "Valid phone number required"),
          city: z.string().min(1, "City is required"),
          vehicleType: z.string().min(1, "Vehicle type is required"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const lead = await createLead({
            name: input.name,
            phone: input.phone,
            city: input.city,
            vehicleType: input.vehicleType,
          });

          if (lead) {
            // Notify owner of new lead submission
            await notifyOwner({
              title: "New Amazon Flex Lead Submission",
              content: `New applicant: ${input.name}\nPhone: ${input.phone}\nCity: ${input.city}\nVehicle: ${input.vehicleType}`,
            });
          }

          return { success: true, lead };
        } catch (error) {
          console.error("Failed to submit lead:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to submit application",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
